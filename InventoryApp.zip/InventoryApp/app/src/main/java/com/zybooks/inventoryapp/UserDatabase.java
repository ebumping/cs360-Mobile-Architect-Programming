package com.zybooks.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import java.util.ArrayList;
import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 2;

    private static UserDatabase mUserDb;

    public enum UserSortOrder {ALPHABETIC};

    public static UserDatabase getInstance(Context context){
        if (mUserDb == null){
            mUserDb = new UserDatabase(context);
        }
        return mUserDb;
    }

    public UserDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }



    private static final class UserTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_PASS = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_NAME + ", " +
                UserTable.COL_PASS + ")");
        /*
        String[] users = { "Dylan", "Tifannie", "Genevieve"};
        for (String u: users){
            User user = new User(u);
            ContentValues values = new ContentValues();
            values.put(UserTable.COL_NAME, user.getName());
            values.put(UserTable.COL_PASS, user.getPass());
            db.insert(UserTable.TABLE, null, values);
        }

         */

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public List<User> getUsers(){
        List<User> users = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String sql = "select * from " + UserTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()){
            do{
                User user = new User();
                user.setId(cursor.getLong(0));
                user.setName(cursor.getString(1));
                user.setPass(cursor.getString(2));
                users.add(user);

            }while (cursor.moveToNext());
        }
        cursor.close();
        return users;
    }

    public boolean addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COL_NAME, user.getName());
        values.put(UserTable.COL_PASS, user.getPass());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.COL_NAME + " = ?", new String[] { user.getName() });
    }

    public User getUser(User user){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE +
                " where " + UserTable.COL_NAME + " = " + user +
                " and " + UserTable.COL_PASS + " = " + user.getPass();
        Cursor cursor = db.rawQuery(sql, new String[] {user.toString()});
        if (!cursor.getString(1).contains(user.getName())){
        //login error
        }else{
            return user;
        }

    }

}

package com.zybooks.inventoryapp;

public class User {

    private long uId;
    private String name;
    private String pass;

    public User(){

    }

    public User(String u) {
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }
    public long getId(){
        return uId;
    }
    public void setId(long id){
        uId = id;
    }

    public void setPass(String pass){
        this.pass = pass;
    }

    public String getPass(){
        return pass;
    }
}
